# UI and interaction rebuild — v98.33

## Source basis

Reviewed source: `SA-Calculator-v98.32-Authoritative-Rebuild.zip`.
Reviewed physical recording: `Screenrecording_20261117_110500.mp4` (98.93 seconds; sampled at one frame per second, 99 frames).

## Rebuilt visual system

- Single brand header on calculator home; one injected toolbar per tool destination.
- Consistent navy surfaces, blue actions, restrained green success results, field borders, radii, typography and spacing.
- Responsive drawer with search, categorized 2-column tool tiles, separate favorites shortcuts and three compact quick actions.
- Bottom navigation with active state and Android safe-area padding.
- Reworked calculator display and 4-column keypad hierarchy.
- Reworked currency and unit converter cards, currency selection rows, rate status, and action button.
- Reworked form cards, suffix fields, result cards, loan schedule, savings fields, unit-price comparison, world-time cards, settings, favorites and history surfaces.
- Scientific functions grouped into a responsive bottom sheet.
- Shared numeric tool keypad presented on demand; text search continues to use text input, and date fields retain date-picker behavior.
- Number Base keypad presented on demand after selecting a base, with a dedicated Done action.
- Light theme parity, small-screen layout, landscape calculator layout and reduced-motion handling.

## Behavior changes

- Currency and Unit Converter dock keypads are hidden; tapping an editable numeric field opens the shared numeric keypad.
- Hexadecimal keypad is hidden until a base row is selected; Done and Escape close it, and navigation away closes it.
- Existing tool routes, field IDs, data-action hooks and calculation IDs are retained to preserve wiring.

## Explicitly preserved

The core math and tool calculation engines, currency provider/cache behavior, unit definitions, settings persistence, history, favorites, localization and app navigation handlers remain in place. This is a UI and shared-input interaction rebuild, not a rewrite of every mathematical formula or provider integration.

## Remaining validation

- Install generated APK on the user's target Android device.
- Compare each of the 18 destinations against screenshots at 320/360/393dp widths and landscape.
- Verify keyboard open/close, text search keyboard, date picker, Back button and drawer focus behavior.
- Verify every currency code/flag pairing and live rates on real network connections.
- Measure frame timing, jank, memory, battery and long-session stability.
