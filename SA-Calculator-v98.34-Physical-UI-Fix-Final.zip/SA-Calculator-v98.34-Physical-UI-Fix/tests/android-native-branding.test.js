const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ROOT = path.resolve(__dirname, '..');

test('premium Android branding assets and native patch script are included', () => {
  const script = fs.readFileSync(path.join(ROOT, 'scripts/patch-android-native.mjs'), 'utf8');
  assert.match(script, /ic_launcher_foreground\.png/);
  assert.match(script, /android:statusBarColor/);
  assert.match(script, /android:windowLightStatusBar/);
  assert.match(script, /android:navigationBarColor/);
  for (const density of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']) {
    for (const name of ['ic_launcher.png','ic_launcher_round.png']) {
      assert.ok(fs.statSync(path.join(ROOT, `assets/brand/android-icons/mipmap-${density}/${name}`)).size > 1000);
    }
  }
  assert.ok(fs.statSync(path.join(ROOT, 'assets/brand/android-icons/mipmap-anydpi-v26/ic_launcher.xml')).size > 100);
});

test('Android build workflow applies native branding after Capacitor sync and before Gradle build', () => {
  const workflow = fs.readFileSync(path.join(ROOT, '.github/workflows/main.yml'), 'utf8');
  const sync = workflow.indexOf('run: npx cap sync android');
  const brand = workflow.indexOf('run: npm run android:brand');
  const gradle = workflow.indexOf('./gradlew --no-daemon --stacktrace assembleDebug');
  assert.ok(sync >= 0 && brand > sync && gradle > brand);
  assert.match(workflow, /scripts\/patch-android-native\.mjs/);
});

test('app uses safe-area layout and premium converter destination remains editable', () => {
  const css = fs.readFileSync(path.join(ROOT, 'assets/css/app.css'), 'utf8');
  const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
  assert.match(css, /padding-top:\s*var\(--safe-top, env\(safe-area-inset-top/);
  assert.match(css, /#screen-currencies \.currency-input-row/);
  const field = html.match(/<div class="input-val-box currency-amount-input currency-result-input" id="cur-to-amount"[^>]*>/);
  assert.ok(field);
  assert.match(field[0], /aria-readonly="false"/);
  assert.doesNotMatch(field[0], /data-readonly="true"/);
});

test('native branding patch copies launcher densities and safely updates generated AppTheme XML', () => {
  const os = require('node:os');
  const { execFileSync } = require('node:child_process');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sa-android-brand-'));
  try {
    fs.mkdirSync(path.join(tmp, 'scripts'), { recursive: true });
    fs.writeFileSync(path.join(tmp, 'package.json'), JSON.stringify({ name: 'sa-calculator', version: '1.98.34-v98.34' }));
    fs.mkdirSync(path.join(tmp, 'android/app/src/main/res/values'), { recursive: true });
    fs.mkdirSync(path.join(tmp, 'android/app/src/main/res/values-v31'), { recursive: true });
    fs.mkdirSync(path.join(tmp, 'android/app/src/main'), { recursive: true });
    fs.cpSync(path.join(ROOT, 'assets/brand/android-icons'), path.join(tmp, 'assets/brand/android-icons'), { recursive: true });
    fs.copyFileSync(path.join(ROOT, 'scripts/patch-android-native.mjs'), path.join(tmp, 'scripts/patch-android-native.mjs'));
    fs.writeFileSync(path.join(tmp, 'android/app/src/main/AndroidManifest.xml'), '<manifest/>');
    fs.writeFileSync(path.join(tmp, 'android/app/build.gradle'), "android { namespace 'com.sacalculator.app'\n    defaultConfig {\n        applicationId 'com.sacalculator.app'\n        versionCode 1\n        versionName \"1.0\"\n    }\n}");
    fs.writeFileSync(path.join(tmp, 'android/app/src/main/res/values/styles.xml'), '<resources><style name="AppTheme.NoActionBar" parent="Theme.MaterialComponents.DayNight.NoActionBar"><item name="android:colorAccent">#000000</item></style></resources>');
    fs.writeFileSync(path.join(tmp, 'android/app/src/main/res/values-v31/themes.xml'), '<resources><style name="AppTheme.NoActionBarLaunch" parent="Theme.SplashScreen"><item name="android:windowBackground">@drawable/splash</item></style></resources>');
    execFileSync(process.execPath, [path.join(tmp, 'scripts/patch-android-native.mjs')], { stdio: 'pipe' });
    const style = fs.readFileSync(path.join(tmp, 'android/app/src/main/res/values/styles.xml'), 'utf8');
    const gradle = fs.readFileSync(path.join(tmp, 'android/app/build.gradle'), 'utf8');
    assert.match(gradle, /versionCode 1098034/);
    assert.match(gradle, /versionName \"1.98.34-v98.34\"/);
    assert.match(style, /android:statusBarColor">#020713/);
    assert.match(style, /android:windowLightStatusBar">false/);
    assert.match(style, /android:navigationBarColor">#020713/);
    assert.ok(fs.statSync(path.join(tmp, 'android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png')).size > 1000);
    assert.ok(fs.existsSync(path.join(tmp, 'android/app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml')));
    const activity = fs.readFileSync(path.join(tmp, 'android/app/src/main/java/com/sacalculator/app/MainActivity.java'), 'utf8');
    assert.match(activity, /WindowCompat\.setDecorFitsSystemWindows\(getWindow\(\), false\)/);
    assert.match(activity, /WindowInsetsCompat\.Type\.displayCutout\(\)/);
    assert.match(activity, /setAppearanceLightStatusBars\(false\)/);
    assert.match(activity, /setPadding\(left \+ safe\.left, top \+ safe\.top/);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
});

test('native branding patch sets a monotonically increasing Android versionCode and exact versionName from package.json', () => {
  const source = fs.readFileSync(path.join(ROOT, 'scripts/patch-android-native.mjs'), 'utf8');
  assert.match(source, /const packageJson = JSON\.parse/);
  assert.match(source, /const versionCode = Number\(semver\[1\]\) \* 1000000 \+ Number\(semver\[2\]\) \* 1000 \+ Number\(semver\[3\]\)/);
  assert.match(source, /versionName \\\"\$\{versionName\}\\\"/);
  assert.match(source, /Android versionCode is outside the supported range/);
});
