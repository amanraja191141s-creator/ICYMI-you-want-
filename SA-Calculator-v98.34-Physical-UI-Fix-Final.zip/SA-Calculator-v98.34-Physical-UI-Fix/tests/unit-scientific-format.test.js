'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extract(name) {
  const start = source.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} not found`);
  const open = source.indexOf('{', start); let depth = 0;
  for (let i = open; i < source.length; i++) {
    if (source[i] === '{') depth++;
    else if (source[i] === '}' && --depth === 0) return source.slice(start, i + 1);
  }
  throw new Error(`Could not extract ${name}`);
}

test('unit results switch to scientific notation only after 12 integer digits', () => {
  const context = {
    Number, Math,
    STATE: { precision: 'auto', trailingZeros: false, thousandsSep: 'comma' }
  };
  vm.runInNewContext(`${extract('formatResultNumber')};${extract('formatUnitResultNumber')};globalThis.format=formatUnitResultNumber;`, context);
  assert.equal(context.format(999999999999), '999,999,999,999');
  assert.equal(context.format(1000000000000), '1e+12');
  assert.equal(context.format(81064793292700000), '8.10647932927e+16');
  assert.equal(context.format(-81064793292700000), '-8.10647932927e+16');
  assert.equal(context.format(0), '0');
  assert.match(context.format(0.000000001), /^1e-9$/);
  assert.equal(context.format(Infinity), 'Error');
});

test('unit converter renders its primary result through the 12-digit scientific formatter', () => {
  assert.match(source, /setElementText\('unit-result-val',\s*formatUnitResultNumber\(res\)\)/);
  assert.match(source, /function formatUnitResultNumber\(value\)/);
});
